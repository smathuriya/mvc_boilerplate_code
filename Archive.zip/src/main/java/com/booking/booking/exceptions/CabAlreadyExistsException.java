package com.booking.booking.exceptions;

public class CabAlreadyExistsException extends RuntimeException{
}
