package com.booking.booking.controllers;

import com.booking.booking.Model.Cab;
import com.booking.booking.database.CabsManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CabsController {

	@Autowired
	private CabsManager cabsManager;

	@RequestMapping(value="/register/cabt", method = RequestMethod.GET)
	public ResponseEntity regiserCab(final String cabId, final String driverName) {
	    cabsManager.createCab(new Cab(cabId, driverName));
	    return ResponseEntity.ok(new Cab(cabId, driverName));
	}
}
