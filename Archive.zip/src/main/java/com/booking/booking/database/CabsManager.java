package com.booking.booking.database;

import java.util.HashMap;
import java.util.Map;

import com.booking.booking.Model.Cab;

import com.booking.booking.exceptions.CabAlreadyExistsException;
import lombok.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
@Component
public class CabsManager {
	
	Map<String, Cab> cabs = new HashMap<>();
	
	public void createCab(@NonNull final Cab newCab) {
	    if (cabs.containsKey(newCab.getId())) {
	      throw new CabAlreadyExistsException();
	    }
		System.out.println(newCab);
	    cabs.put(newCab.getId(), newCab);
	  }

}
